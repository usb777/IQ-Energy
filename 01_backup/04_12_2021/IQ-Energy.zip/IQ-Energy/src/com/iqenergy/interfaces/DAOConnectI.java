package com.iqenergy.interfaces;

public interface DAOConnectI 
{
/*	 // REAL Database Server
	public static final String URL =  "jdbc:mysql://mysql3000.mochahost.com/usb777_advicenyc";
	public static final  String USER = "usb777_admin";
	public static final String PASSWORD   ="Fight160583dsoregon";
	
	*/
	
	
	//Localhost Database Server
	/*
	public static final String URL =  "jdbc:mysql://localhost:3306/usb777_advicenyc";
	public static final  String USER = "root";
	public static final String PASSWORD   ="";
	
	 * */
	// String url = "jdbc:mysql://localhost:3306/db_grsumf?useUnicode=true&characterEncoding=UTF-8"; //for SQL and oracle or any other db server this url differs. where ravi is the database name and 3306 is the port where mysql is running

	//public static final String URL =  "jdbc:mysql://localhost:3306/iqekz?useUnicode=true&characterEncoding=UTF-8";
	public static final String URL =  "jdbc:mysql://localhost:3306/iqekz?useUnicode=true&characterEncoding=utf8";
	public static final  String USER = "root";
	public static final String PASSWORD   ="";
	
	
	
	
	
	
	
	
}
